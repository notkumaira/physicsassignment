public struct Boundary
{
    public float Up { get; }
    public float Down { get; }
    public float Left { get; }
    public float Right { get; }

    public Boundary(float up, float down, float left, float right)
    {
        Up = up;
        Down = down;
        Left = left;
        Right = right;
    }
}
