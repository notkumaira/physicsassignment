using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class menuManager : MonoBehaviour
{

    public GameObject Loadscene;
    public void ShowMenu()
    {
        Time.timeScale = 1;
        SceneManager.Loadscene("main");
    }
}