﻿using System;

internal class SceneManager
{
    internal static void Loadscene(string v)
    {
        throw new NotImplementedException();
    }
}