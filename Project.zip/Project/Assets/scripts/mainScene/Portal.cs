﻿using System;
using UnityEngine;

public class Portal
{
    internal bool HasExpired()
    {
        throw new NotImplementedException();
    }

    internal Vector2 GetNormal()
    {
        throw new NotImplementedException();
    }

    internal object GetOtherPortal()
    {
        throw new NotImplementedException();
    }
}

