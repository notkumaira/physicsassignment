using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class puckScript : MonoBehaviour
{
    public scores scoresInstance;
    public static bool goalScored { get; private set; }
    public Rigidbody2D puck;
    private Vector2 puckVelocity;

    private Rigidbody2D rbody;
    public float maxSpeed;
    private bool aiScored;
    private bool isPlayerHitting = false;
    private bool isAIHitting = false;
    private Vector2 startPosition;
    private float minDistanceToPlayer = 1f;
    private float minDistanceToGoal = 2f;

    void Start()
    {
        rbody = GetComponent<Rigidbody2D>();
        goalScored = false;
        startPosition = rbody.position;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (!goalScored)
        {
            if (collision.tag == "aiGoal")
            {
                if (isPlayerHitting)
                {
                    scoresInstance.Increase(scores.Score.aiScore);
                    ResetHitFlags();
                }
                else
                {
                    scoresInstance.Increase(scores.Score.playerScore);
                }

                goalScored = true;
                StartCoroutine(ResetPuck(false));
            }
            else if (collision.tag == "playerGoal")
            {
                if (isAIHitting)
                {
                    scoresInstance.Increase(scores.Score.playerScore);
                    ResetHitFlags();
                }
                else
                {
                    scoresInstance.Increase(scores.Score.aiScore);
                }

                goalScored = true;
                StartCoroutine(ResetPuck(true));
            }
            else if (collision.tag == "portal")
            {
                // Save the puck's velocity before it enters the portal
                puckVelocity = rbody.velocity;
            }
        }
    }

    private IEnumerator ResetPuck(bool v)
    {
        yield return new WaitForSecondsRealtime(0);
        goalScored = false;
        rbody.velocity = rbody.position = new Vector2(0, 0);
        rbody.position = startPosition;
    }


    private void FixedUpdate()
    {
        rbody.velocity = Vector2.ClampMagnitude(rbody.velocity, maxSpeed);
    }

    public void CenterPuck()
    {
        rbody.position = new Vector2(0, 0);
    }

    private void OnTriggerExit2D()
    {
        if (!goalScored)
        {
            // Set the puck's velocity to the saved velocity
            rbody.velocity = puckVelocity;
        }
    }

    private void MovePuckAwayFromCollider(Collider2D collider)  
    {
        // Calculate the direction from the puck to the center of the collider
        Vector2 direction = puck.position - new Vector2(collider.bounds.center.x, collider.bounds.center.y);
          
        // Move the puck away from the collider by a small distance in the opposite direction
        puck.MovePosition(puck.position + direction.normalized * 0.1f);
    }


    public void ResetPosition()
    {
        ResetPositionIfValid(startPosition);
    }

    private void ResetPositionIfValid(Vector2 position)
    {
        bool validPosition = true;
        foreach (var player in GameObject.FindGameObjectsWithTag("Player"))
        {
            if (Vector2.Distance(player.transform.position, position) < minDistanceToPlayer)
            {
                validPosition = false;
                break;
            }
        }

        if (validPosition)
        {
            foreach (var goal in GameObject.FindGameObjectsWithTag("Goal"))
            {
                if (Vector2.Distance(goal.transform.position, position) < minDistanceToGoal)
                {
                    validPosition = false;
                    break;
                }
            }
        }

        // check if the puck is within the screen bounds
        if (validPosition && position.x >= -9.5f && position.x <= 9.5f && position.y >= -5f && position.y <= 5f)
        {
            rbody.position = position;
        }
        else
        {
            Debug.LogWarning("Unable to reset puck to a valid position.");

            // Set the puck's position to the nearest valid position within the screen bounds
            Vector2 newPosition = new Vector2(Mathf.Clamp(position.x, -9.5f, 9.5f), Mathf.Clamp(position.y, -5f, 5f));
            rbody.position = newPosition;
        }
    }

    private void ResetHitFlags()
    {
        isPlayerHitting = false;
        isAIHitting = false;
    }
}