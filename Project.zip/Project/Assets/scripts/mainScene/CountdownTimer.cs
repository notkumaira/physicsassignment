using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CountdownTimer : MonoBehaviour
{
    public float startingTime = 3f; // Starting time is 3 seconds
    [SerializeField] Text countdownText;
    [SerializeField] GameObject countdownPanel; // Reference to the countdown panel

    private float currentTime;

    public aiScript ai; // Reference to the aiScript component

    void Start()
    {
        // Initialize the current time to the starting time
        currentTime = startingTime;

        // Activate the countdown panel at the start of the scene
        countdownPanel.SetActive(true);
        countdownText.text = currentTime.ToString("0"); // Display the starting time
    }

    void Update()
    {
        // Decrease the current time by the amount of time passed since the last frame
        currentTime -= Time.deltaTime;

        // If the current time is greater than 0, update the countdown text
        if (currentTime > 0)
        {
            countdownText.text = currentTime.ToString("0");
        }
        // Otherwise, hide the countdown panel and trigger the start of the game
        else
        {
            countdownPanel.SetActive(false); // Hide the countdown panel
            StartGame(); // Trigger the start of the game
        }
    }

    bool gameStarted = false;

    void StartGame()
    {
        if (!gameStarted)
        {
            // Implement the code to start the game here
            Debug.Log("Game started!");
            gameStarted = true;

            // Set the canMove flag to true on the aiScript component
            ai.CountdownEnded();
        }
    }

    public void RestartTimer()
    {
        // Reset the current time to the starting time
        currentTime = startingTime;

        // Reactivate the countdown panel
        countdownPanel.SetActive(true);
        countdownText.text = currentTime.ToString("3"); // Display the starting time

        // Start the countdown timer
        Start();
    }
}