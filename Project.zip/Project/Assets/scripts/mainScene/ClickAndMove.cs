using UnityEngine;

public class ClickAndMove : MonoBehaviour
{
    bool clickedThisFrame = true;
    bool canMove;

    Rigidbody2D rbody;
    Vector2 startPosition;

    public Transform Margin;

    Boundary playerMargin;

    Collider2D playerCollider;

    void Start()
    {
        rbody = GetComponent<Rigidbody2D>();
        startPosition = rbody.position;
        playerCollider = GetComponent<Collider2D>();

        Boundary boundary = new Boundary(Margin.GetChild(0).position.y,
                                            Margin.GetChild(1).position.y,
                                            Margin.GetChild(2).position.x,
                                            Margin.GetChild(3).position.x);
        playerMargin = boundary;
    }

    void Update()
    {
        if (Input.GetMouseButton(0))
        {
            Vector2 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            if (clickedThisFrame)
            {
                clickedThisFrame = false;

                if(playerCollider.OverlapPoint(mousePosition))
                {
                    canMove = true;
                }
                else
                {
                    canMove = false;
                }
            }
            if (canMove)
            {
                Vector2 clampedMousePosition = new Vector2(Mathf.Clamp(mousePosition.x, playerMargin.Left,
                                                                                        playerMargin.Right),
                                                           Mathf.Clamp(mousePosition.y, playerMargin.Down,
                                                                                        playerMargin.Up));
                rbody.MovePosition(clampedMousePosition);
            }
        }
        else
        {
            clickedThisFrame = true;
        }
    }

    public void ResetPosition()
    {
        rbody.position = startPosition;
    }
}




