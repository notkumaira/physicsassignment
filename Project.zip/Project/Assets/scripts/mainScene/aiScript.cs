using UnityEngine;

public class aiScript : MonoBehaviour
{
    public float MaxSpeed;
    public Rigidbody2D rbody;
    private Vector2 startPosition;

    public Rigidbody2D puck;

    public Transform Margin;
    private Boundary playerMargin;

    public Transform puckBorder;
    private Boundary puckBoundary;

    private Vector2 TargetPosition;

    private bool hasEnteredOpponentsHalf = true;
    private float offsetXFromTarget;

    private bool canMove = false; // Add a flag to check if the countdown has ended

    public GameObject aiPaddle { get; private set; }
    public GameObject playerPaddle { get; private set; }

    private void Start()
    {
        rbody = GetComponent<Rigidbody2D>();
        startPosition = rbody.position;

        playerMargin = new Boundary(
            Margin.GetChild(0).position.y,
            Margin.GetChild(1).position.y,
            Margin.GetChild(2).position.x,
            Margin.GetChild(3).position.x
        );

        puckBoundary = new Boundary(
            puckBorder.GetChild(0).position.y,
            puckBorder.GetChild(1).position.y,
            puckBorder.GetChild(2).position.x,
            puckBorder.GetChild(3).position.x
        );
    }

    private void FixedUpdate()
    {
        // Check if the countdown has ended before moving the AI
        if (canMove && !puckScript.goalScored)
        {
            float Speed;

            if (puck != null && puck.position.y < puckBoundary.Down)
            {
                if (hasEnteredOpponentsHalf)
                {
                    hasEnteredOpponentsHalf = false;
                    offsetXFromTarget = Random.Range(-1f, 1f);
                }

                Speed = MaxSpeed * Random.Range(0.1f, 0.3f);
                TargetPosition = new Vector2(Mathf.Clamp(puck.position.x + offsetXFromTarget, playerMargin.Left, playerMargin.Right),
                                             startPosition.y);
            }
            else
            {
                hasEnteredOpponentsHalf = true;

                Speed = Random.Range(MaxSpeed * 0.4f, MaxSpeed);
                TargetPosition = new Vector2(Mathf.Clamp(puck.position.x, playerMargin.Left, playerMargin.Right),
                                             Mathf.Clamp(puck.position.y, playerMargin.Down, playerMargin.Up));
            }

            rbody.MovePosition(Vector2.MoveTowards(rbody.position, TargetPosition, Speed * Time.fixedDeltaTime));
        }
    }

    internal void ResetPosition()
    {
        rbody.position = startPosition;
    }

    public struct Boundary
    {
        public float Up;
        public float Down;
        public float Left;
        public float Right;

        public Boundary(float up, float down, float left, float right)
        {
            Up = up;
            Down = down;
            Left = left;
            Right = right;
        }
    }

    // Add a function to set the canMove flag to true when the countdown timer has ended
    public void CountdownEnded()
    {
        canMove = true;
    }

    }



