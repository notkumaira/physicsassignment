using UnityEngine;
using UnityEngine.UI;

public class scores : MonoBehaviour
{
    public enum Score
    {
        aiScore, playerScore
    }

    public Text aiScoreText, playerScoreText;
    private int _aiScore, _playerScore;

    public UiManager uiManager;

    public int maxScore;

    public int AiScore
    {
        get { return _aiScore; }
        set
        {
            _aiScore = value;
            aiScoreText.text = _aiScore.ToString();
            if (_aiScore == maxScore)
            {
                Time.timeScale = 0;
                uiManager.ShowRestartCanvas(true);
            }
        }
    }

    public int PlayerScore
    {
        get { return _playerScore; }
        set
        {
            _playerScore = value;
            playerScoreText.text = _playerScore.ToString();
            if (_playerScore == maxScore)
            {
                Time.timeScale = 0;
                uiManager.ShowRestartCanvas(false);
            }
        }
    }
    public aiScript script;


    public void Increase(Score whichScore)
    {


        if (whichScore == Score.playerScore)
            playerScoreText.text = (++_playerScore).ToString();
        else
            aiScoreText.text = (++_aiScore).ToString();

        if (_aiScore == maxScore || _playerScore == maxScore)
            uiManager.ShowRestartCanvas(_aiScore == maxScore);
    }


    public void ResetScores()
    {
        AiScore = PlayerScore = 0;
    }

    void Start()
    {
        maxScore = 5;
    }
}