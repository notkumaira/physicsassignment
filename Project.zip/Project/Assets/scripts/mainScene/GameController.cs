using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    // Reference to the CountdownTimer script
    public CountdownTimer countdownTimer;

    void Start()
    {
        // Start the countdown timer at the beginning of the scene
        countdownTimer.RestartTimer();
    }

    void Update()
    {
        // Your game logic goes here
    }

    // Call this method when the restart button is pressed
    public void RestartGame()
    {
        // Restart the countdown timer
        countdownTimer.RestartTimer();

        // Implement the code to reset the game here
    }
}




