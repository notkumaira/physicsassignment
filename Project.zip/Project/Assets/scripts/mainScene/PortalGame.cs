using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PortalGame : MonoBehaviour
{
    public Transform destination;
    public Transform[] portals;
    public float portalDurationMin = 15f;
    public float portalDurationMax = 20f;

    private GameObject puck;
    private Animation anim;
    private Rigidbody2D puckRbody;
    private bool isInPortal;

    private Vector2 velocityBeforePortal;

    private void Awake()
    {
        puck = GameObject.FindGameObjectWithTag("puck");
        anim = puck.GetComponent<Animation>();
        puckRbody = puck.GetComponent<Rigidbody2D>();
    }

    private void Update()
    {
        if (portals != null)
        {
            foreach (var portal in portals)
            {
                if (portal != null)
                {
                    var pos = portal.transform.position;
                    pos.y = Mathf.Clamp(pos.y, -4f, 4f);
                    portal.transform.position = pos;
                }
            }
        }
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("puck"))
        {
            if (!isInPortal && Vector2.Distance(puck.transform.position, transform.position) > 0.3f)
            {
                // Check if the puck is colliding with the portal it just exited from
                if (collision.gameObject == destination.gameObject)
                {
                    return; // Skip the portal in animation
                }

                StartCoroutine(PortalIn());
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("puck"))
        {
            isInPortal = false;
        }
    }

    IEnumerator PortalIn()
    {
        isInPortal = true;
        puckRbody.simulated = false;
        anim.Play("Portal In");
        StartCoroutine(MoveInPortal());
        yield return new WaitForSeconds(0.5f);
        velocityBeforePortal = puckRbody.velocity;
        puck.transform.position = destination.position;
        anim.Play("Portal Out");
        yield return new WaitForSeconds(0.5f);
        puckRbody.velocity = velocityBeforePortal;
        puckRbody.simulated = true;
    }

    IEnumerator MoveInPortal()
    {
        float timer = 0;
        while (timer < 0.5f)
        {
            puck.transform.position = Vector2.MoveTowards(puck.transform.position, transform.position, 3 * Time.deltaTime);
            timer += Time.deltaTime;
            yield return null;
        }
        yield break;
    }
}


