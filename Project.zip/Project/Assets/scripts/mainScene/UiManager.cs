using UnityEngine;

public class UiManager : MonoBehaviour

{
    public float maxScore;

    [Header("Canvas")]
    public GameObject CanvasGame;
    public GameObject CanvasRestart;

    [Header("CanvasRestart")]
    public GameObject Win;
    public GameObject Lose;
    public GameObject Restart;

    [Header("Other")]
    public scores scores;

    public puckScript puckScript;
    public ClickAndMove ClickAndMove;
    public aiScript aiScript;

    private void Start()
    {
        // Hide the CanvasRestart panel and restart button at the start of the scene
        CanvasRestart.SetActive(false);
        Restart.SetActive(false);
        maxScore = 5;
    }

    public void ShowRestartCanvas(bool didAiWin)
    {
        if ((didAiWin && scores.AiScore == scores.maxScore) || (!didAiWin && scores.PlayerScore == scores.maxScore))
        {
            Time.timeScale = 0;

            CanvasGame.SetActive(false);
            CanvasRestart.SetActive(true);
            Restart.SetActive(true);

            if (didAiWin)
            {
                Win.SetActive(false);
                Lose.SetActive(true);
            }
            else
            {
                Win.SetActive(true);
                Lose.SetActive(false);
            }
        }
    }

    public void RestartGame()
    {
        Time.timeScale = 1;

        CanvasGame.SetActive(true);
        CanvasRestart.SetActive(false);
        Restart.SetActive(false);

        scores.ResetScores();
        puckScript.CenterPuck();
        ClickAndMove.ResetPosition();
        aiScript.ResetPosition();

            // Restart the game
        FindObjectOfType<CountdownTimer>().RestartTimer();
        
    }

    public void ShowMenu()
    {
        Time.timeScale = 1;
        SceneManager.Loadscene
            ("menu");
    }


}


